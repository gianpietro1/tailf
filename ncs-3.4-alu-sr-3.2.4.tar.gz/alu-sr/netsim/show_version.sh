#!/bin/bash

cat <<EOF
TiMOS-C-11.0.B1-100 cpm/hops ALCATEL SR 7750 Copyright (c) 2000-2013 Alcatel-Lucent.
All rights reserved. All use subject to applicable license agreements.
Built on Sun May 26 11:59:39 PDT 2013 by builder in /rel11.0/b1/B1-100/panos/main
NETSIM
EOF
