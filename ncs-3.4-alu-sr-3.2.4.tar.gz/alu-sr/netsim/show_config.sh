#!/bin/bash

cat big.cfg

